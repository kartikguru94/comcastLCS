package com.comcast.interview.model;

import java.util.List;

import lombok.Data;

@Data
public class lcs {

	private List<SetOfStrings> lcs;
	
}

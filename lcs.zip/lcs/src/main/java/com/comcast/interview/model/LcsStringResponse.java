package com.comcast.interview.model;

import lombok.Data;

@Data
public class LcsStringResponse {

	private lcs format;
	
}

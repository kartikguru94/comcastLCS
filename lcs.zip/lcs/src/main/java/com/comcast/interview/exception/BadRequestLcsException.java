package com.comcast.interview.exception;

public class BadRequestLcsException extends RuntimeException {
	 public BadRequestLcsException(String message){
	        super(message);
	    }
}

package com.comcast.interview.lcs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LcsApplicationTests {

	@Test
	void contextLoads() {
	}

}
